// destroy any existing tooltipMenuDivs
$('body').off();


console.log('off');